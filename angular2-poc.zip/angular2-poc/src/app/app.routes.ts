import { NgModule }     from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {EmployeeComponent} from './employee/employee.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

const APP_ROUTES: Routes = [
    { path: '', redirectTo: 'home', pathMatch : 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'employees', component: EmployeeComponent }
];


@NgModule({
  imports: [
    RouterModule.forRoot(APP_ROUTES)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}
