import { Component, OnInit } from '@angular/core';
import { Headers } from '@angular/http';
import { EmployeeServices } from './services/employee.service';
import { Employee } from './interface/employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeServices]
})
export class EmployeeComponent implements OnInit {
  public employees: Employee[] = [];
  public employee: Employee = {
    id: 0,
    name: '',
    address: ''
  };

  constructor(private _employeeServices: EmployeeServices) { }

  getEmployeeList() {
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    this._employeeServices.getEmployeeList(headers).subscribe(employeeList => {
      this.employees = employeeList;
      console.log(this.employees);
    });
  }

  save() {
    this._employeeServices.saveEmployee(this.employee);
    this.employees.push(this.employee);
  }

  ngOnInit() {
    this.getEmployeeList();
  }

}
