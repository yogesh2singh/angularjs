import { Http, Response, Headers } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class EmployeeServices {

    constructor(private http: Http) {
    }

    getEmployeeList(headers: Headers) {
        let _ruleServiceUrl = '/employee.mock.json';
        return this.http.get(_ruleServiceUrl, {
            headers: headers
        }).map((res) => {
            return res.json();
        }).catch(this.handleError);
    }

    saveEmployee(employee){
        console.log(JSON.stringify(employee));
    }

    private handleError(error: Response) {
        console.error(error.json());
        return Observable.throw(error.json().error.message || 'Server error');
    }
}
